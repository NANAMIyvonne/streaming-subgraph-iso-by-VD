#include"Utility.h"

bool Utility::compareEle(int v, int w){
	return v < w;
}

