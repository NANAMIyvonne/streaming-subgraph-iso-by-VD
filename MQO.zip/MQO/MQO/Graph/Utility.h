#ifndef UTILITY
#define UTILITY


class Utility{
public:
	static bool compareEle(int v, int w);
};




#endif